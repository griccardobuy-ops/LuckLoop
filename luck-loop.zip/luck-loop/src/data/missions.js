// ────────────────────────────────────────────────────
// MISSIONI REALI
// Basate su comportamenti che aumentano esposizione
// a opportunità nella vita reale (nessuna magia).
// ────────────────────────────────────────────────────

export const REAL_MISSIONS = [
  // ── SOCIALE ──────────────────────────────────────
  {
    id: 'r01',
    category: 'sociale',
    energy: ['bassa', 'media', 'alta'],
    title: 'Scrivi a qualcuno che non senti da un po\'',
    description: 'Manda un messaggio breve e sincero a una persona che stimi. Non chiedere nulla, solo un contatto genuino.',
    impact: 'medio',
    impactNote: 'Le reti sociali dormienti sono una delle fonti più sottovalutate di opportunità inaspettate.',
  },
  {
    id: 'r02',
    category: 'sociale',
    energy: ['media', 'alta'],
    title: 'Parla con uno sconosciuto',
    description: 'Fai una domanda o un complimento sincero a una persona che non conosci. Bar, negozio, coda: qualunque contesto va bene.',
    impact: 'alto',
    impactNote: 'Le connessioni deboli (weak ties) aprono porte che le amicizie strette raramente raggiungono.',
  },
  {
    id: 'r03',
    category: 'sociale',
    energy: ['bassa'],
    title: 'Rispondi a quel messaggio rimasto in sospeso',
    description: 'C\'è qualcuno che aspetta una tua risposta. Fallo ora, anche con due righe.',
    impact: 'basso',
    impactNote: 'L\'affidabilità nelle piccole cose costruisce reputazione nel tempo.',
  },
  {
    id: 'r04',
    category: 'sociale',
    energy: ['media', 'alta'],
    title: 'Partecipa a un evento (fisico o online)',
    description: 'Trova un evento, meetup o incontro nel tuo settore o area di interesse. Basta essere presenti.',
    impact: 'alto',
    impactNote: 'La presenza fisica o attiva aumenta la probabilità di essere ricordati e coinvolti.',
  },
  {
    id: 'r05',
    category: 'sociale',
    energy: ['bassa', 'media'],
    title: 'Completa una micro-referenza',
    description: 'Pensa a due persone che potrebbero trarre vantaggio dal conoscersi. Fai una presentazione via messaggio.',
    impact: 'alto',
    impactNote: 'Chi connette gli altri viene percepito come risorsa preziosa e viene ricordato con gratitudine.',
  },

  // ── ESPLORAZIONE ──────────────────────────────────
  {
    id: 'r06',
    category: 'esplorazione',
    energy: ['bassa', 'media', 'alta'],
    title: 'Cambia percorso',
    description: 'Oggi prendi una strada diversa dal solito. Anche solo 10 minuti a piedi in una direzione nuova.',
    impact: 'basso',
    impactNote: 'Piccoli cambiamenti di routine espongono il cervello a stimoli nuovi e aumentano la prontezza cognitiva.',
  },
  {
    id: 'r07',
    category: 'esplorazione',
    energy: ['media', 'alta'],
    title: 'Entra in un posto che non hai mai frequentato',
    description: 'Un bar, una libreria, un negozio, un parco. Entra senza obiettivo preciso e osserva.',
    impact: 'medio',
    impactNote: 'L\'esposizione a nuovi ambienti allarga il campo delle possibilità percepite.',
  },
  {
    id: 'r08',
    category: 'esplorazione',
    energy: ['bassa'],
    title: 'Leggi un articolo fuori dal tuo solito perimetro',
    description: 'Cerca un argomento completamente fuori dalla tua comfort zone. Dedica 10 minuti senza giudicare.',
    impact: 'basso',
    impactNote: 'Le idee contaminate da settori diversi producono soluzioni creative difficili da generare dentro la propria nicchia.',
  },
  {
    id: 'r09',
    category: 'esplorazione',
    energy: ['media', 'alta'],
    title: 'Prova qualcosa che hai rimandato da mesi',
    description: 'Quella cosa nella lista "prima o poi". Fallo per 20 minuti, solo per capire come ci si sente.',
    impact: 'alto',
    impactNote: 'L\'action bias – agire nonostante l\'incertezza – è uno dei tratti più correlati alle opportunità percepite come "fortuna".',
  },
  {
    id: 'r10',
    category: 'esplorazione',
    energy: ['alta'],
    title: 'Fai una cosa che ti spaventa un po\'',
    description: 'Non qualcosa di pericoloso: qualcosa che ti mette a disagio in modo sano. Una presentazione, una chiamata, un tentativo.',
    impact: 'alto',
    impactNote: 'La zona di disagio evolutivo è dove avvengono la maggior parte delle trasformazioni significative.',
  },

  // ── ABITUDINI ─────────────────────────────────────
  {
    id: 'r11',
    category: 'abitudini',
    energy: ['bassa', 'media', 'alta'],
    title: 'Riordina un singolo spazio',
    description: 'Scrivania, borsa, inbox email, una cartella sul computer. Un posto solo. Ordinato e finito.',
    impact: 'basso',
    impactNote: 'Gli ambienti ordinati riducono il carico cognitivo e migliorano la capacità decisionale.',
  },
  {
    id: 'r12',
    category: 'abitudini',
    energy: ['bassa', 'media'],
    title: 'Cammina 20 minuti senza schermo',
    description: 'Solo tu e il mondo. Nessun podcast, nessun audio. Lascia che la mente vada dove vuole.',
    impact: 'medio',
    impactNote: 'Il "default mode network" del cervello, attivo nel riposo, è associato alla creatività e alla risoluzione di problemi complessi.',
  },
  {
    id: 'r13',
    category: 'abitudini',
    energy: ['bassa'],
    title: 'Completa un micro-task rimasto aperto',
    description: 'Quella piccola cosa che hai nella testa da giorni. Meno di 10 minuti. Chiudila.',
    impact: 'basso',
    impactNote: 'I task aperti consumano banda cognitiva inconsapevolmente. Chiuderli libera risorse mentali reali.',
  },
  {
    id: 'r14',
    category: 'abitudini',
    energy: ['media', 'alta'],
    title: 'Dedica 30 minuti a qualcosa che stai imparando',
    description: 'Una skill, una lingua, uno strumento. Anche solo 30 minuti di pratica deliberata contano.',
    impact: 'alto',
    impactNote: 'Il compounding dell\'apprendimento: piccole sessioni regolari producono risultati sproporzionati nel tempo.',
  },
  {
    id: 'r15',
    category: 'abitudini',
    energy: ['media'],
    title: 'Scrivi 3 cose che vuoi che accadano',
    description: 'Non una lista dei desideri: scrivi come se fossero già in corso. Presente, concreto, specifico.',
    impact: 'medio',
    impactNote: 'La scrittura di intenzioni attiva l\'attention filter del cervello e aumenta il riconoscimento di opportunità rilevanti.',
  },
  {
    id: 'r16',
    category: 'abitudini',
    energy: ['bassa', 'media'],
    title: 'Fai una domanda a qualcuno più esperto di te',
    description: 'Una sola domanda, genuina. Non chiedere consigli generici: chiedi qualcosa di specifico su un problema reale.',
    impact: 'alto',
    impactNote: 'Fare buone domande è una delle competenze più rare e valorizzate in qualsiasi contesto professionale e sociale.',
  },
];

// ────────────────────────────────────────────────────
// MISSIONI SCARAMANTICHE
// Puramente simboliche – dichiarate come intrattenimento.
// Non influenzano la realtà.
// ────────────────────────────────────────────────────

export const SUPERSTITION_MISSIONS = [
  {
    id: 's01',
    type: 'numero',
    title: 'Il tuo numero del giorno',
    description: 'Ogni giorno la matematica casuale produce un numero. Puoi trattarlo come un segno, un amuleto o ignorarlo completamente.',
    action: 'numero',
  },
  {
    id: 's02',
    type: 'ruota',
    title: 'Gira la ruota della fortuna',
    description: 'Un antico rituale digitale. Gira, osserva dove si ferma. Il significato è quello che vuoi dargli.',
    action: 'ruota',
  },
  {
    id: 's03',
    type: 'rituale',
    title: 'Scegli un colore portafortuna',
    description: 'Indossa o cerca oggi questo colore. È un gioco di attenzione selettiva: lo vedrai ovunque.',
    action: 'colore',
  },
  {
    id: 's04',
    type: 'rituale',
    title: 'La parola del giorno',
    description: 'Una parola estratta casualmente. Usala mentalmente come filtro della giornata. Solo per gioco.',
    action: 'parola',
  },
  {
    id: 's05',
    type: 'rituale',
    title: 'Il tuo animale guida del giorno',
    description: 'Dalla tradizione simbolica mondiale: un animale per ogni giorno. Nessun significato reale, solo narrativa.',
    action: 'animale',
  },
  {
    id: 's06',
    type: 'numero',
    title: 'I numeri del giorno',
    description: 'Tre numeri estratti per te. Usali come preferisci, o non usarli per niente.',
    action: 'numeri_tripli',
  },
];

// Dati per i rituali scaramantici
export const RITUAL_DATA = {
  colori: [
    { nome: 'Oro', hex: '#C9A84C', simbolo: 'abbondanza' },
    { nome: 'Verde', hex: '#4CAF50', simbolo: 'crescita' },
    { nome: 'Blu', hex: '#2196F3', simbolo: 'chiarezza' },
    { nome: 'Rosso', hex: '#F44336', simbolo: 'energia' },
    { nome: 'Viola', hex: '#9C27B0', simbolo: 'intuizione' },
    { nome: 'Arancio', hex: '#FF9800', simbolo: 'creatività' },
    { nome: 'Bianco', hex: '#F5F5F5', simbolo: 'inizio' },
    { nome: 'Turchese', hex: '#4ECDC4', simbolo: 'comunicazione' },
  ],
  parole: [
    'Apertura', 'Presenza', 'Slancio', 'Calma', 'Curiosità',
    'Radici', 'Respiro', 'Chiarezza', 'Movimento', 'Fiducia',
    'Leggerezza', 'Ascolto', 'Intenzione', 'Flusso', 'Confine',
  ],
  animali: [
    { nome: 'Volpe', simbolo: 'astuzia e adattamento' },
    { nome: 'Aquila', simbolo: 'visione ampia' },
    { nome: 'Lupo', simbolo: 'istinto e branco' },
    { nome: 'Tartaruga', simbolo: 'perseveranza lenta' },
    { nome: 'Farfalla', simbolo: 'trasformazione' },
    { nome: 'Corvo', simbolo: 'intelligenza' },
    { nome: 'Leone', simbolo: 'coraggio' },
    { nome: 'Delfino', simbolo: 'gioia e connessione' },
    { nome: 'Gufo', simbolo: 'saggezza notturna' },
    { nome: 'Serpente', simbolo: 'rinnovamento' },
  ],
  settori_ruota: [
    'Energia', 'Connessioni', 'Creatività', 'Stabilità',
    'Avventura', 'Riflessione', 'Coraggio', 'Pazienza',
  ],
};

export const IMPACT_LABELS = {
  basso: { label: 'Impatto lieve', color: 'text-cream-dim', bg: 'bg-cream/10' },
  medio: { label: 'Impatto medio', color: 'text-gold', bg: 'bg-gold/10' },
  alto: { label: 'Impatto alto', color: 'text-teal', bg: 'bg-teal/10' },
};

export const ENERGY_LEVELS = [
  { id: 'bassa', label: 'Bassa energia', emoji: '🌙', desc: 'Giornata tranquilla, missioni leggere' },
  { id: 'media', label: 'Media energia', emoji: '⚡', desc: 'In forma, pronto a qualcosa di concreto' },
  { id: 'alta', label: 'Alta energia', emoji: '🔥', desc: 'Al massimo, sfida più intensa' },
];

export const BADGES = [
  { id: 'primo_passo', label: 'Primo Passo', desc: 'Prima missione completata', emoji: '🌱', threshold: 1 },
  { id: 'tre_giorni', label: 'Tripletta', desc: '3 giorni di fila', emoji: '🎯', threshold: 3 },
  { id: 'sette_giorni', label: 'Settimana Intera', desc: '7 giorni consecutivi', emoji: '🔥', threshold: 7 },
  { id: 'venti_giorni', label: 'Abitudine Solida', desc: '20 missioni completate', emoji: '⚡', threshold: 20 },
  { id: 'cinquanta', label: 'Loop Master', desc: '50 missioni completate', emoji: '🌀', threshold: 50 },
];
