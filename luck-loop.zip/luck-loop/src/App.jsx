import { useState } from 'react';
import { useDailyLoop } from './hooks/useDailyLoop';
import Header from './components/Header';
import EnergySelector from './components/EnergySelector';
import RealMissionCard from './components/RealMissionCard';
import SupMissionCard from './components/SupMissionCard';
import StreakBar from './components/StreakBar';
import BadgeToast from './components/BadgeToast';
import HowItWorks from './components/HowItWorks';
import HistoryPage from './components/HistoryPage';

const ENERGY_EMOJI = { bassa: '🌙', media: '⚡', alta: '🔥' };

export default function App() {
  const [page, setPage] = useState('home'); // 'home' | 'how' | 'history'
  const [showDebug, setShowDebug] = useState(false);

  const {
    dailyState,
    streak,
    badges,
    totalCompleted,
    newBadge,
    energySelected,
    today,
    selectEnergy,
    completeRealMission,
    completeSupMission,
    regenerateDay,
    fullReset,
  } = useDailyLoop();

  const bothCompleted = dailyState?.realCompleted && dailyState?.supCompleted;

  return (
    <div className="min-h-dvh bg-navy-900">
      {/* Ambient background glow */}
      <div className="fixed inset-0 pointer-events-none overflow-hidden">
        <div className="absolute -top-32 -right-32 w-96 h-96 bg-gold/5 rounded-full blur-3xl" />
        <div className="absolute -bottom-32 -left-32 w-96 h-96 bg-teal/5 rounded-full blur-3xl" />
      </div>

      <div className="relative max-w-lg mx-auto px-4 pb-16">
        <Header
          onShowHow={() => setPage(page === 'how' ? 'home' : 'how')}
          onShowHistory={() => setPage(page === 'history' ? 'home' : 'history')}
          currentPage={page}
        />

        {/* ── HOW IT WORKS PAGE ─────────────────── */}
        {page === 'how' && (
          <HowItWorks onBack={() => setPage('home')} />
        )}

        {/* ── HISTORY PAGE ──────────────────────── */}
        {page === 'history' && (
          <HistoryPage
            badges={badges}
            totalCompleted={totalCompleted}
            streak={streak}
            onBack={() => setPage('home')}
          />
        )}

        {/* ── HOME PAGE ─────────────────────────── */}
        {page === 'home' && (
          <>
            {/* Date + tagline */}
            <div className="mb-6">
              <p className="text-cream-dim text-sm">
                {new Date().toLocaleDateString('it-IT', {
                  weekday: 'long', day: 'numeric', month: 'long'
                })}
              </p>
              <h1 className="font-display text-3xl text-cream mt-1 leading-tight">
                La tua giornata
                {dailyState?.energy && (
                  <span className="ml-2">{ENERGY_EMOJI[dailyState.energy]}</span>
                )}
              </h1>
            </div>

            {/* Streak bar (solo se c'è qualcosa da mostrare) */}
            {(totalCompleted > 0 || streak.current > 0) && (
              <div className="mb-5">
                <StreakBar
                  streak={streak}
                  badges={badges}
                  totalCompleted={totalCompleted}
                />
              </div>
            )}

            {/* ENERGY SELECTOR – se non è ancora stata scelta */}
            {!energySelected && (
              <EnergySelector onSelect={selectEnergy} />
            )}

            {/* DAILY MISSIONS – se l'energia è stata scelta */}
            {energySelected && dailyState && (
              <div className="space-y-4">
                {/* Real mission */}
                <RealMissionCard
                  mission={dailyState.realMission}
                  completed={dailyState.realCompleted}
                  onComplete={completeRealMission}
                />

                {/* Superstition mission */}
                <SupMissionCard
                  mission={dailyState.supMission}
                  ritualData={dailyState.ritualData}
                  completed={dailyState.supCompleted}
                  onComplete={completeSupMission}
                />

                {/* Completion celebration */}
                {bothCompleted && (
                  <div className="text-center py-4 animate-fade-up">
                    <div className="text-3xl mb-2">✨</div>
                    <h3 className="font-display text-xl text-cream mb-1">Giornata completata</h3>
                    <p className="text-cream-dim text-sm">
                      Torna domani per una nuova missione
                    </p>
                    {streak.current > 1 && (
                      <div className="mt-3 inline-flex items-center gap-2 bg-gold/10 border border-gold/20 rounded-full px-4 py-1.5">
                        <span className="text-gold text-sm font-semibold">
                          🔥 {streak.current} giorni di fila
                        </span>
                      </div>
                    )}
                  </div>
                )}

                {/* Debug / admin tools */}
                <div className="pt-4 border-t border-white/5">
                  <button
                    onClick={() => setShowDebug(!showDebug)}
                    className="text-cream/20 text-xs hover:text-cream/40 transition-colors"
                  >
                    ··· opzioni sviluppatore
                  </button>
                  {showDebug && (
                    <div className="mt-3 flex flex-wrap gap-2 animate-fade-up">
                      <button
                        onClick={regenerateDay}
                        className="btn-ghost text-xs py-1.5 px-3"
                      >
                        🔄 Rigenera giornata
                      </button>
                      <button
                        onClick={() => {
                          if (confirm('Vuoi davvero resettare tutti i dati?')) fullReset();
                        }}
                        className="text-xs py-1.5 px-3 border border-red-500/30 text-red-400/70 
                                   rounded-lg hover:border-red-500/60 hover:text-red-400 transition-colors"
                      >
                        🗑️ Reset completo
                      </button>
                    </div>
                  )}
                </div>
              </div>
            )}
          </>
        )}
      </div>

      {/* Badge toast notification */}
      <BadgeToast badge={newBadge} />
    </div>
  );
}
