import { useState, useEffect, useCallback } from 'react';
import {
  getDailyState, saveDailyState, addToHistory,
  getStreak, updateStreak, getBadges, awardBadge,
  getTotalCompleted, incrementTotalCompleted, getTodayString, resetAllData,
} from '../utils/storage';
import {
  REAL_MISSIONS, SUPERSTITION_MISSIONS, RITUAL_DATA, BADGES,
} from '../data/missions';
import {
  seededPickOne, getDailyLuckyNumber, getDailyTripleNumbers,
  getDailyWheelResult,
} from '../utils/seed';

function buildDailyContent(dateStr, energyLevel) {
  // Filtra missioni reali per livello energetico
  const eligible = REAL_MISSIONS.filter(m => m.energy.includes(energyLevel));
  const realMission = seededPickOne(eligible.length ? eligible : REAL_MISSIONS, dateStr, energyLevel);

  // Missione scaramantica (indipendente dall'energia)
  const supMission = seededPickOne(SUPERSTITION_MISSIONS, dateStr, 'sup');

  // Dati rituali del giorno
  const colore = seededPickOne(RITUAL_DATA.colori, dateStr, 'colore');
  const parola = seededPickOne(RITUAL_DATA.parole, dateStr, 'parola');
  const animale = seededPickOne(RITUAL_DATA.animali, dateStr, 'animale');
  const luckyNumber = getDailyLuckyNumber(dateStr);
  const tripleNumbers = getDailyTripleNumbers(dateStr);
  const wheelIndex = getDailyWheelResult(dateStr);

  return {
    date: dateStr,
    energy: energyLevel,
    realMission,
    supMission,
    ritualData: { colore, parola, animale, luckyNumber, tripleNumbers, wheelIndex },
    realCompleted: false,
    supCompleted: false,
  };
}

export function useDailyLoop() {
  const today = getTodayString();

  const [dailyState, setDailyState] = useState(null);
  const [streak, setStreak] = useState({ current: 0, best: 0, lastDate: null });
  const [badges, setBadges] = useState([]);
  const [totalCompleted, setTotalCompleted] = useState(0);
  const [newBadge, setNewBadge] = useState(null);
  const [energySelected, setEnergySelected] = useState(false);

  // Carica stato iniziale
  useEffect(() => {
    const saved = getDailyState();
    setStreak(getStreak());
    setBadges(getBadges());
    setTotalCompleted(getTotalCompleted());

    if (saved && saved.date === today) {
      setDailyState(saved);
      setEnergySelected(true);
    }
    // Se non c'è stato salvato per oggi, aspetta che l'utente selezioni l'energia
  }, [today]);

  // Seleziona livello energetico e genera contenuto giornaliero
  const selectEnergy = useCallback((level) => {
    const content = buildDailyContent(today, level);
    saveDailyState(content);
    setDailyState(content);
    setEnergySelected(true);
  }, [today]);

  // Segna missione reale come completata
  const completeRealMission = useCallback(() => {
    if (!dailyState || dailyState.realCompleted) return;

    const updated = { ...dailyState, realCompleted: true };
    saveDailyState(updated);
    setDailyState(updated);

    // Aggiorna storico
    addToHistory({
      date: today,
      missionId: dailyState.realMission.id,
      missionTitle: dailyState.realMission.title,
      category: dailyState.realMission.category,
      energy: dailyState.energy,
    });

    // Aggiorna streak
    const newStreak = updateStreak(today);
    setStreak(newStreak);

    // Totale completate
    const newTotal = incrementTotalCompleted();
    setTotalCompleted(newTotal);

    // Controlla badge
    checkAndAwardBadges(newStreak.current, newTotal);
  }, [dailyState, today]);

  // Segna missione scaramantica come completata (nessun effetto su streak)
  const completeSupMission = useCallback(() => {
    if (!dailyState || dailyState.supCompleted) return;
    const updated = { ...dailyState, supCompleted: true };
    saveDailyState(updated);
    setDailyState(updated);
  }, [dailyState]);

  function checkAndAwardBadges(currentStreak, total) {
    const currentBadges = getBadges();
    for (const badge of BADGES) {
      if (currentBadges.includes(badge.id)) continue;
      const shouldAward =
        (badge.id === 'primo_passo' && total >= 1) ||
        (badge.id === 'tre_giorni' && currentStreak >= 3) ||
        (badge.id === 'sette_giorni' && currentStreak >= 7) ||
        (badge.id === 'venti_giorni' && total >= 20) ||
        (badge.id === 'cinquanta' && total >= 50);

      if (shouldAward) {
        awardBadge(badge.id);
        setBadges(prev => [...prev, badge.id]);
        setNewBadge(badge);
        setTimeout(() => setNewBadge(null), 4000);
        break; // un badge alla volta
      }
    }
  }

  // Rigenera giornata (debug/admin)
  const regenerateDay = useCallback(() => {
    if (dailyState) {
      const content = buildDailyContent(today, dailyState.energy || 'media');
      // forza rigenerazione con timestamp
      const forcedContent = { ...content, _forcedAt: Date.now() };
      saveDailyState(forcedContent);
      setDailyState(forcedContent);
    }
  }, [dailyState, today]);

  // Reset completo (debug)
  const fullReset = useCallback(() => {
    resetAllData();
    setDailyState(null);
    setStreak({ current: 0, best: 0, lastDate: null });
    setBadges([]);
    setTotalCompleted(0);
    setEnergySelected(false);
  }, []);

  return {
    dailyState,
    streak,
    badges,
    totalCompleted,
    newBadge,
    energySelected,
    today,
    selectEnergy,
    completeRealMission,
    completeSupMission,
    regenerateDay,
    fullReset,
  };
}
