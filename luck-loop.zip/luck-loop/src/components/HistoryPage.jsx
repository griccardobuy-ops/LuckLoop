import { getHistory } from '../utils/storage';
import { BADGES } from '../data/missions';

const CATEGORY_ICONS = {
  sociale: '🤝',
  esplorazione: '🧭',
  abitudini: '⚙️',
};

const ENERGY_EMOJI = {
  bassa: '🌙',
  media: '⚡',
  alta: '🔥',
};

export default function HistoryPage({ badges, totalCompleted, streak, onBack }) {
  const history = getHistory();
  const earnedBadges = BADGES.filter(b => badges.includes(b.id));
  const lockedBadges = BADGES.filter(b => !badges.includes(b.id));

  return (
    <div className="animate-fade-up max-w-lg mx-auto">
      <button
        onClick={onBack}
        className="flex items-center gap-2 text-cream-dim hover:text-cream text-sm mb-6 transition-colors"
      >
        ← Torna alla home
      </button>

      <h2 className="font-display text-2xl text-cream mb-6">Il tuo archivio</h2>

      {/* Stats row */}
      <div className="grid grid-cols-3 gap-3 mb-6">
        <div className="card-glass p-3 text-center">
          <div className="text-gold font-display text-2xl">{totalCompleted}</div>
          <div className="text-cream-dim text-xs">missioni</div>
        </div>
        <div className="card-glass p-3 text-center">
          <div className="text-teal font-display text-2xl">{streak.current}</div>
          <div className="text-cream-dim text-xs">streak attuale</div>
        </div>
        <div className="card-glass p-3 text-center">
          <div className="text-cream font-display text-2xl">{streak.best}</div>
          <div className="text-cream-dim text-xs">record streak</div>
        </div>
      </div>

      {/* Badges */}
      <div className="card-glass p-4 mb-6">
        <h3 className="font-semibold text-cream mb-4">Badge</h3>
        <div className="space-y-2">
          {BADGES.map(badge => {
            const earned = badges.includes(badge.id);
            return (
              <div
                key={badge.id}
                className={`flex items-center gap-3 p-2.5 rounded-lg transition-colors ${
                  earned ? 'bg-gold/10 border border-gold/20' : 'opacity-40'
                }`}
              >
                <span className="text-2xl">{badge.emoji}</span>
                <div>
                  <div className={`text-sm font-semibold ${earned ? 'text-gold' : 'text-cream-dim'}`}>
                    {badge.label}
                  </div>
                  <div className="text-xs text-cream-dim">{badge.desc}</div>
                </div>
                {earned && (
                  <div className="ml-auto">
                    <svg className="w-4 h-4 text-gold" fill="currentColor" viewBox="0 0 20 20">
                      <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                    </svg>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </div>

      {/* History list */}
      <div className="card-glass p-4">
        <h3 className="font-semibold text-cream mb-4">Missioni completate</h3>
        {history.length === 0 ? (
          <p className="text-cream-dim text-sm text-center py-4">
            Nessuna missione completata ancora.<br />
            Inizia oggi!
          </p>
        ) : (
          <div className="space-y-2">
            {history.map((entry, i) => (
              <div key={i} className="flex items-center gap-3 bg-navy-800 rounded-lg p-3">
                <span className="text-lg">{CATEGORY_ICONS[entry.category] || '🎯'}</span>
                <div className="flex-1 min-w-0">
                  <div className="text-cream text-sm font-medium truncate">{entry.missionTitle}</div>
                  <div className="text-cream-dim text-xs">
                    {new Date(entry.completedAt).toLocaleDateString('it-IT', {
                      day: 'numeric', month: 'short'
                    })}
                    {' · '}
                    {ENERGY_EMOJI[entry.energy]} {entry.energy}
                  </div>
                </div>
                <div className="w-5 h-5 rounded-full bg-teal/20 flex items-center justify-center shrink-0">
                  <svg className="w-3 h-3 text-teal" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M5 13l4 4L19 7" />
                  </svg>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
