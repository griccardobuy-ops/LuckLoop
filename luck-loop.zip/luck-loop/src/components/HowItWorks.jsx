export default function HowItWorks({ onBack }) {
  return (
    <div className="animate-fade-up max-w-lg mx-auto">
      {/* Back button */}
      <button
        onClick={onBack}
        className="flex items-center gap-2 text-cream-dim hover:text-cream text-sm mb-6 transition-colors"
      >
        ← Torna alla home
      </button>

      <h2 className="font-display text-2xl text-cream mb-6">Come funziona Luck Loop</h2>

      {/* Real part */}
      <div className="card-teal p-5 mb-4">
        <div className="flex items-center gap-2 mb-3">
          <span className="tag-real">Missione Reale</span>
        </div>
        <h3 className="font-display text-lg text-cream mb-2">
          La fortuna si costruisce con il comportamento
        </h3>
        <p className="text-cream-dim text-sm leading-relaxed mb-3">
          La ricerca in psicologia e scienze comportamentali mostra che le persone 
          percepite come "fortunate" hanno in comune comportamenti specifici: 
          mantengono reti sociali attive, si espongono a nuove esperienze, 
          completano micro-azioni quotidiane che aumentano la loro visibilità e le opportunità di incontro.
        </p>
        <p className="text-cream-dim text-sm leading-relaxed">
          Le missioni reali di Luck Loop sono calibrate su questi meccanismi. 
          Nessuna promessa: solo un modo per aumentare le probabilità che cose buone 
          abbiano l'opportunità di accadere.
        </p>
      </div>

      {/* Science note */}
      <div className="bg-navy-700 border border-white/10 rounded-xl p-4 mb-4">
        <div className="text-xs text-cream-dim uppercase tracking-wider mb-2 font-semibold">
          La scienza dietro
        </div>
        <div className="space-y-2 text-sm text-cream-dim">
          <div className="flex gap-2">
            <span className="text-teal shrink-0">→</span>
            <span>Le <strong className="text-cream">reti sociali dormienti</strong> (Levin et al., 2022) producono più opportunità di lavoro delle connessioni attive</span>
          </div>
          <div className="flex gap-2">
            <span className="text-teal shrink-0">→</span>
            <span>La <strong className="text-cream">esposizione a nuovi stimoli</strong> attiva percorsi cognitivi associati alla creatività e al problem solving</span>
          </div>
          <div className="flex gap-2">
            <span className="text-teal shrink-0">→</span>
            <span>I <strong className="text-cream">micro-task completati</strong> riducono il cognitive load e migliorano la qualità decisionale</span>
          </div>
        </div>
      </div>

      {/* Game part */}
      <div className="card-gold p-5 mb-4">
        <div className="flex items-center gap-2 mb-3">
          <span className="tag-game">Gioco Simbolico</span>
        </div>
        <h3 className="font-display text-lg text-cream mb-2">
          La parte scaramantica: solo intrattenimento
        </h3>
        <p className="text-cream-dim text-sm leading-relaxed mb-3">
          I rituali simbolici esistono in ogni cultura umana. 
          Hanno un effetto psicologico reale — migliorano le performance sportive, 
          riducono l'ansia pre-esame, aumentano la sensazione di controllo — 
          ma non influenzano la realtà esterna.
        </p>
        <p className="text-cream-dim text-sm leading-relaxed">
          La sezione "Gioco Simbolico" di Luck Loop è <strong className="text-gold">puro intrattenimento</strong>. 
          I numeri sono casuali, la ruota non predice nulla, i colori non portano fortuna. 
          È un gioco consapevole, dichiarato come tale.
        </p>
      </div>

      {/* What we don't claim */}
      <div className="bg-navy-800 border border-white/5 rounded-xl p-4 mb-6">
        <div className="text-xs text-cream-dim uppercase tracking-wider mb-3 font-semibold">
          Cosa Luck Loop NON dice mai
        </div>
        <div className="space-y-1.5 text-sm">
          {[
            'Che la fortuna esista come forza causale',
            'Che i rituali influenzino eventi esterni',
            'Che completare le missioni garantisca risultati',
            'Che i numeri o i simboli abbiano significato reale',
          ].map((item, i) => (
            <div key={i} className="flex gap-2 text-cream-dim">
              <span className="text-red-400 shrink-0">✕</span>
              <span>{item}</span>
            </div>
          ))}
        </div>
      </div>

      {/* Streak explanation */}
      <div className="card-glass p-4 mb-6">
        <h4 className="font-semibold text-cream mb-2">La streak: perché conta</h4>
        <p className="text-cream-dim text-sm leading-relaxed">
          La streak registra solo le missioni <strong className="text-teal">reali</strong> completate di fila. 
          Non è gamification vuota: è un indicatore di consistenza comportamentale, 
          l'unica cosa che produce cambiamenti misurabili nel tempo.
        </p>
      </div>

      <button onClick={onBack} className="btn-primary w-full">
        Torna alla mia giornata
      </button>
    </div>
  );
}
