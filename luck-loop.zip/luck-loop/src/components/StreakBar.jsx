import { BADGES } from '../data/missions';

export default function StreakBar({ streak, badges, totalCompleted }) {
  const earnedBadges = BADGES.filter(b => badges.includes(b.id));

  return (
    <div className="flex items-center justify-between gap-3 bg-navy-700 border border-white/10 rounded-xl px-4 py-3">
      {/* Streak */}
      <div className="flex items-center gap-2">
        <span className="text-lg">🔥</span>
        <div>
          <div className="text-gold font-bold text-lg leading-none">{streak.current}</div>
          <div className="text-cream-dim text-xs">giorni di fila</div>
        </div>
      </div>

      {/* Divider */}
      <div className="w-px h-8 bg-white/10" />

      {/* Total */}
      <div className="flex items-center gap-2">
        <span className="text-lg">🎯</span>
        <div>
          <div className="text-cream font-bold text-lg leading-none">{totalCompleted}</div>
          <div className="text-cream-dim text-xs">missioni totali</div>
        </div>
      </div>

      {/* Divider */}
      <div className="w-px h-8 bg-white/10" />

      {/* Badges */}
      <div className="flex items-center gap-1">
        {earnedBadges.length === 0 ? (
          <div className="text-cream-dim text-xs">nessun badge</div>
        ) : (
          earnedBadges.slice(-3).map(badge => (
            <span key={badge.id} className="text-lg" title={badge.label}>
              {badge.emoji}
            </span>
          ))
        )}
      </div>
    </div>
  );
}
