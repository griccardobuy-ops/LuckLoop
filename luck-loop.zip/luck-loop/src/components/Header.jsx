export default function Header({ onShowHow, onShowHistory, currentPage }) {
  return (
    <header className="flex items-center justify-between py-4 mb-2">
      {/* Logo */}
      <div className="flex items-center gap-2.5">
        <div className="w-8 h-8 rounded-lg bg-gold/20 border border-gold/30 flex items-center justify-center">
          <span className="text-gold text-sm">∞</span>
        </div>
        <span className="font-display text-lg text-cream tracking-wide">Luck Loop</span>
      </div>

      {/* Nav */}
      <nav className="flex items-center gap-1">
        <button
          onClick={onShowHistory}
          className={`px-3 py-1.5 rounded-lg text-sm transition-colors ${
            currentPage === 'history'
              ? 'bg-white/10 text-cream'
              : 'text-cream-dim hover:text-cream'
          }`}
        >
          Archivio
        </button>
        <button
          onClick={onShowHow}
          className={`px-3 py-1.5 rounded-lg text-sm transition-colors ${
            currentPage === 'how'
              ? 'bg-white/10 text-cream'
              : 'text-cream-dim hover:text-cream'
          }`}
        >
          Come funziona
        </button>
      </nav>
    </header>
  );
}
