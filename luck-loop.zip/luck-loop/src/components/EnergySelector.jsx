import { useState } from 'react';
import { ENERGY_LEVELS } from '../data/missions';

export default function EnergySelector({ onSelect }) {
  const [selected, setSelected] = useState(null);

  function handleConfirm() {
    if (selected) onSelect(selected);
  }

  return (
    <div className="animate-fade-up">
      <div className="text-center mb-8">
        <p className="text-cream-dim text-sm uppercase tracking-widest mb-3">Come ti senti oggi?</p>
        <h2 className="font-display text-2xl text-cream">
          Scegli il tuo livello di energia
        </h2>
        <p className="text-cream-dim text-sm mt-2">
          Questo calibra la difficoltà della missione reale
        </p>
      </div>

      <div className="grid gap-3 mb-6">
        {ENERGY_LEVELS.map(level => (
          <button
            key={level.id}
            onClick={() => setSelected(level.id)}
            className={`
              w-full text-left p-4 rounded-xl border transition-all duration-200
              focus:outline-none focus:ring-2 focus:ring-gold/40
              ${selected === level.id
                ? 'border-gold bg-gold/10 shadow-lg shadow-gold/10'
                : 'border-white/10 bg-navy-700 hover:border-white/30'
              }
            `}
          >
            <div className="flex items-center gap-4">
              <span className="text-2xl">{level.emoji}</span>
              <div>
                <div className={`font-semibold ${selected === level.id ? 'text-gold' : 'text-cream'}`}>
                  {level.label}
                </div>
                <div className="text-sm text-cream-dim">{level.desc}</div>
              </div>
              {selected === level.id && (
                <div className="ml-auto w-5 h-5 rounded-full bg-gold flex items-center justify-center">
                  <svg className="w-3 h-3 text-navy-900" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M5 13l4 4L19 7" />
                  </svg>
                </div>
              )}
            </div>
          </button>
        ))}
      </div>

      <button
        onClick={handleConfirm}
        disabled={!selected}
        className={`
          w-full py-3.5 rounded-xl font-semibold transition-all duration-200
          ${selected
            ? 'bg-gold text-navy-900 hover:bg-gold-light active:scale-98 animate-pulse-gold'
            : 'bg-navy-600 text-cream-dim cursor-not-allowed'
          }
        `}
      >
        Genera la mia giornata →
      </button>
    </div>
  );
}
