import { useState } from 'react';
import SpinWheel from './SpinWheel';

export default function SupMissionCard({ mission, ritualData, completed, onComplete }) {
  const [interacted, setInteracted] = useState(false);

  function handleInteraction() {
    setInteracted(true);
    if (!completed) onComplete();
  }

  function renderContent() {
    const { action } = mission;

    if (action === 'ruota') {
      return (
        <SpinWheel
          targetIndex={ritualData.wheelIndex}
          onSpun={handleInteraction}
        />
      );
    }

    if (action === 'numero') {
      return (
        <div className="text-center">
          <div
            className="font-display text-8xl text-gold shimmer-text cursor-pointer select-none
                       hover:scale-110 transition-transform duration-300"
            onClick={handleInteraction}
          >
            {ritualData.luckyNumber}
          </div>
          <p className="text-cream-dim text-xs mt-2">Tocca il numero per riceverlo</p>
        </div>
      );
    }

    if (action === 'numeri_tripli') {
      return (
        <div className="text-center">
          <div className="flex justify-center gap-4 mb-3">
            {ritualData.tripleNumbers.map((n, i) => (
              <button
                key={i}
                onClick={handleInteraction}
                className={`
                  w-16 h-16 rounded-xl font-display text-2xl font-bold border-2 transition-all duration-300
                  ${interacted || completed
                    ? 'border-gold text-gold bg-gold/10'
                    : 'border-white/20 text-cream-dim hover:border-gold/50'}
                `}
              >
                {n}
              </button>
            ))}
          </div>
          <p className="text-cream-dim text-xs">I tuoi tre numeri del giorno</p>
        </div>
      );
    }

    if (action === 'colore') {
      const { colore } = ritualData;
      return (
        <div className="text-center">
          <button
            onClick={handleInteraction}
            className="w-24 h-24 rounded-2xl mx-auto block mb-3 shadow-lg
                       hover:scale-105 active:scale-95 transition-transform duration-200 border-2 border-white/10"
            style={{ backgroundColor: colore.hex }}
            aria-label={`Scegli ${colore.nome}`}
          />
          <div className="font-display text-xl text-cream">{colore.nome}</div>
          <div className="text-cream-dim text-xs mt-1">simbolo di {colore.simbolo}</div>
          <p className="text-cream-dim/60 text-xs mt-3">Tocca il colore per riceverlo</p>
        </div>
      );
    }

    if (action === 'parola') {
      return (
        <div className="text-center">
          <button
            onClick={handleInteraction}
            className="group"
          >
            <div className={`
              font-display text-4xl mb-2 transition-all duration-300
              ${interacted || completed ? 'text-gold shimmer-text' : 'text-cream-dim hover:text-cream'}
            `}>
              {ritualData.parola}
            </div>
          </button>
          <p className="text-cream-dim text-xs">La tua parola-filtro per oggi</p>
          {!interacted && !completed && (
            <p className="text-cream-dim/60 text-xs mt-1">Tocca per riceverla</p>
          )}
        </div>
      );
    }

    if (action === 'animale') {
      const { animale } = ritualData;
      return (
        <div className="text-center">
          <button
            onClick={handleInteraction}
            className="text-6xl mb-3 block mx-auto hover:scale-110 transition-transform duration-200"
          >
            🐾
          </button>
          <div className="font-display text-2xl text-gold">{animale.nome}</div>
          <div className="text-cream-dim text-sm mt-1">{animale.simbolo}</div>
          <p className="text-cream-dim/60 text-xs mt-3">Tocca per ricevere il tuo animale</p>
        </div>
      );
    }

    return null;
  }

  return (
    <div className="card-gold p-5 animate-fade-up" style={{ animationDelay: '0.2s' }}>
      {/* Header with disclaimer */}
      <div className="flex items-start justify-between gap-3 mb-1">
        <span className="tag-game">Gioco Simbolico</span>
        <span className="text-xl">🎲</span>
      </div>

      {/* Disclaimer */}
      <p className="text-gold/60 text-xs mb-4 italic">
        Solo intrattenimento – nessun effetto reale
      </p>

      {/* Title */}
      <h3 className="font-display text-xl text-cream mb-2 leading-snug">
        {mission.title}
      </h3>

      <p className="text-cream-dim text-sm leading-relaxed mb-5">
        {mission.description}
      </p>

      {/* Interactive content */}
      <div className="bg-navy-800 rounded-xl p-5 mb-4">
        {renderContent()}
      </div>

      {/* Completion status */}
      {(completed || interacted) && (
        <div className="flex items-center gap-2 text-gold/70 text-xs">
          <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
          </svg>
          Rituale completato · solo per gioco
        </div>
      )}
    </div>
  );
}
