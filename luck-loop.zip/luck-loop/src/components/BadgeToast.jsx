export default function BadgeToast({ badge }) {
  if (!badge) return null;

  return (
    <div className="fixed bottom-6 left-1/2 -translate-x-1/2 z-50 animate-fade-up">
      <div className="bg-navy-700 border border-gold/40 rounded-2xl px-5 py-4 shadow-2xl shadow-black/50
                      flex items-center gap-4 min-w-64">
        <span className="text-3xl">{badge.emoji}</span>
        <div>
          <div className="text-xs text-gold uppercase tracking-widest font-semibold">Nuovo badge!</div>
          <div className="text-cream font-display text-lg leading-tight">{badge.label}</div>
          <div className="text-cream-dim text-xs">{badge.desc}</div>
        </div>
      </div>
    </div>
  );
}
