import { useState } from 'react';
import { IMPACT_LABELS } from '../data/missions';

const CATEGORY_ICONS = {
  sociale: '🤝',
  esplorazione: '🧭',
  abitudini: '⚙️',
};

export default function RealMissionCard({ mission, completed, onComplete }) {
  const [flipped, setFlipped] = useState(false);
  const [showConfirm, setShowConfirm] = useState(false);
  const impact = IMPACT_LABELS[mission.impact];

  // Trigger flip animation on mount
  useState(() => {
    setTimeout(() => setFlipped(true), 100);
  });

  function handleComplete() {
    if (showConfirm) {
      onComplete();
      setShowConfirm(false);
    } else {
      setShowConfirm(true);
    }
  }

  return (
    <div className={`card-teal p-5 transition-all duration-500 ${flipped ? 'animate-flip-in' : 'opacity-0'}`}>
      {/* Header */}
      <div className="flex items-start justify-between gap-3 mb-4">
        <div className="flex items-center gap-2">
          <span className="tag-real">Missione Reale</span>
        </div>
        <span className="text-xl">{CATEGORY_ICONS[mission.category] || '🎯'}</span>
      </div>

      {/* Title */}
      <h3 className="font-display text-xl text-cream mb-2 leading-snug">
        {mission.title}
      </h3>

      {/* Description */}
      <p className="text-cream-dim text-sm leading-relaxed mb-4">
        {mission.description}
      </p>

      {/* Impact badge */}
      <div className={`inline-flex items-center gap-2 px-3 py-1.5 rounded-lg ${impact.bg} mb-5`}>
        <span className={`text-xs font-semibold ${impact.color}`}>{impact.label}</span>
      </div>

      {/* Impact explanation */}
      <div className="border-t border-white/10 pt-4 mb-5">
        <p className="text-xs text-cream-dim leading-relaxed">
          <span className="text-teal font-medium">Perché funziona: </span>
          {mission.impactNote}
        </p>
      </div>

      {/* Complete button */}
      {completed ? (
        <div className="flex items-center gap-3 bg-teal/10 border border-teal/30 rounded-xl p-3">
          <div className="w-8 h-8 rounded-full bg-teal flex items-center justify-center shrink-0">
            <svg className="w-4 h-4 text-navy-900" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M5 13l4 4L19 7" />
            </svg>
          </div>
          <div>
            <div className="text-teal font-semibold text-sm">Missione completata</div>
            <div className="text-cream-dim text-xs">Ottimo lavoro, la streak continua</div>
          </div>
        </div>
      ) : showConfirm ? (
        <div className="space-y-2">
          <p className="text-cream-dim text-xs text-center mb-2">Hai davvero completato questa missione?</p>
          <div className="flex gap-2">
            <button
              onClick={() => setShowConfirm(false)}
              className="flex-1 btn-ghost text-sm py-2"
            >
              No, aspetta
            </button>
            <button
              onClick={handleComplete}
              className="flex-1 bg-teal text-navy-900 font-semibold py-2 rounded-xl text-sm hover:bg-teal/90 active:scale-95 transition-all"
            >
              Sì, completata ✓
            </button>
          </div>
        </div>
      ) : (
        <button
          onClick={handleComplete}
          className="w-full border border-teal/40 text-teal font-semibold py-3 rounded-xl 
                     hover:bg-teal/10 active:scale-98 transition-all duration-150 text-sm"
        >
          Segna come completata
        </button>
      )}
    </div>
  );
}
