import { useState } from 'react';
import { RITUAL_DATA } from '../data/missions';

const COLORS = [
  '#C9A84C', '#4ECDC4', '#9C6FDE', '#E86B5F',
  '#4CAF76', '#E8A84C', '#4C7BE8', '#E84CAD',
];

export default function SpinWheel({ targetIndex, onSpun }) {
  const [spinning, setSpinning] = useState(false);
  const [rotation, setRotation] = useState(0);
  const [revealed, setRevealed] = useState(false);

  const sectors = RITUAL_DATA.settori_ruota;
  const sectorAngle = 360 / sectors.length;

  function handleSpin() {
    if (spinning || revealed) return;
    setSpinning(true);

    // Calcola rotazione per atterrare sul settore target
    const targetAngle = targetIndex * sectorAngle;
    const spins = 5 * 360; // 5 giri completi
    const finalRotation = rotation + spins + (360 - targetAngle - sectorAngle / 2);

    setRotation(finalRotation);

    setTimeout(() => {
      setSpinning(false);
      setRevealed(true);
      onSpun?.();
    }, 3000);
  }

  return (
    <div className="flex flex-col items-center gap-4">
      {/* Wheel container */}
      <div className="relative w-48 h-48">
        {/* Pointer */}
        <div className="absolute top-0 left-1/2 -translate-x-1/2 -translate-y-1 z-10">
          <div className="w-0 h-0 border-l-[8px] border-r-[8px] border-b-[16px] border-l-transparent border-r-transparent border-b-gold" />
        </div>

        {/* SVG wheel */}
        <svg
          viewBox="0 0 200 200"
          className="w-full h-full drop-shadow-lg"
          style={{
            transform: `rotate(${rotation}deg)`,
            transition: spinning ? 'transform 3s cubic-bezier(0.17, 0.67, 0.12, 0.99)' : 'none',
          }}
        >
          {sectors.map((sector, i) => {
            const startAngle = i * sectorAngle;
            const endAngle = startAngle + sectorAngle;
            const startRad = (startAngle - 90) * (Math.PI / 180);
            const endRad = (endAngle - 90) * (Math.PI / 180);
            const x1 = 100 + 95 * Math.cos(startRad);
            const y1 = 100 + 95 * Math.sin(startRad);
            const x2 = 100 + 95 * Math.cos(endRad);
            const y2 = 100 + 95 * Math.sin(endRad);
            const midAngle = (startAngle + endAngle) / 2 - 90;
            const midRad = midAngle * (Math.PI / 180);
            const textX = 100 + 65 * Math.cos(midRad);
            const textY = 100 + 65 * Math.sin(midRad);

            return (
              <g key={i}>
                <path
                  d={`M 100 100 L ${x1} ${y1} A 95 95 0 0 1 ${x2} ${y2} Z`}
                  fill={COLORS[i % COLORS.length]}
                  stroke="#0D1117"
                  strokeWidth="1.5"
                />
                <text
                  x={textX}
                  y={textY}
                  textAnchor="middle"
                  dominantBaseline="middle"
                  fill="white"
                  fontSize="8"
                  fontWeight="600"
                  fontFamily="Inter, sans-serif"
                  transform={`rotate(${midAngle + 90}, ${textX}, ${textY})`}
                >
                  {sector}
                </text>
              </g>
            );
          })}
          {/* Center circle */}
          <circle cx="100" cy="100" r="12" fill="#0D1117" stroke="#C9A84C" strokeWidth="2" />
        </svg>
      </div>

      {/* Result */}
      {revealed && (
        <div className="text-center animate-fade-up">
          <div className="text-gold font-display text-lg">{sectors[targetIndex]}</div>
          <div className="text-cream-dim text-xs">Il simbolo del tuo giorno</div>
        </div>
      )}

      {/* Button */}
      {!revealed && (
        <button
          onClick={handleSpin}
          disabled={spinning}
          className={`btn-primary text-sm px-8 ${spinning ? 'opacity-50 cursor-not-allowed' : ''}`}
        >
          {spinning ? 'In rotazione...' : 'Gira la ruota'}
        </button>
      )}
    </div>
  );
}
