// Generatore pseudo-random seedato sulla data
// Garantisce che per la stessa data si ottengano
// sempre le stesse missioni (fino al reset manuale).

function hashCode(str) {
  let hash = 0;
  for (let i = 0; i < str.length; i++) {
    const char = str.charCodeAt(i);
    hash = (hash << 5) - hash + char;
    hash |= 0;
  }
  return Math.abs(hash);
}

// PRNG semplice seedato
function seededRandom(seed) {
  let s = seed;
  return function () {
    s = (s * 1664525 + 1013904223) & 0xffffffff;
    return (s >>> 0) / 0xffffffff;
  };
}

// Seleziona N elementi casuali da un array usando seed
export function seededPick(array, count, dateStr, salt = '') {
  const seed = hashCode(dateStr + salt);
  const rng = seededRandom(seed);
  const shuffled = [...array];

  for (let i = shuffled.length - 1; i > 0; i--) {
    const j = Math.floor(rng() * (i + 1));
    [shuffled[i], shuffled[j]] = [shuffled[j], shuffled[i]];
  }

  return shuffled.slice(0, count);
}

// Seleziona 1 elemento
export function seededPickOne(array, dateStr, salt = '') {
  return seededPick(array, 1, dateStr, salt)[0];
}

// Genera un numero "fortunato" 1-99 basato sulla data
export function getDailyLuckyNumber(dateStr) {
  const seed = hashCode(dateStr + 'lucky_number');
  const rng = seededRandom(seed);
  return Math.floor(rng() * 99) + 1;
}

// Genera tre numeri 1-90 (stile tombola)
export function getDailyTripleNumbers(dateStr) {
  const seed = hashCode(dateStr + 'triple');
  const rng = seededRandom(seed);
  const nums = new Set();
  while (nums.size < 3) {
    nums.add(Math.floor(rng() * 90) + 1);
  }
  return [...nums];
}

// Indice settore ruota 0-7
export function getDailyWheelResult(dateStr) {
  const seed = hashCode(dateStr + 'wheel');
  const rng = seededRandom(seed);
  return Math.floor(rng() * 8);
}
