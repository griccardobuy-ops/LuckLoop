// ────────────────────────────────────────────────────
// Storage abstraction layer
// Attualmente usa localStorage.
// Per migrare a un DB: sostituisci le funzioni qui sotto
// con chiamate API, mantenendo la stessa interfaccia.
// ────────────────────────────────────────────────────

const KEYS = {
  DAILY_STATE: 'll_daily_state',
  HISTORY: 'll_history',
  STREAK: 'll_streak',
  BADGES: 'll_badges',
  TOTAL_COMPLETED: 'll_total',
};

// Ottieni lo stato giornaliero corrente
export function getDailyState() {
  try {
    const raw = localStorage.getItem(KEYS.DAILY_STATE);
    return raw ? JSON.parse(raw) : null;
  } catch {
    return null;
  }
}

// Salva lo stato giornaliero
export function saveDailyState(state) {
  try {
    localStorage.setItem(KEYS.DAILY_STATE, JSON.stringify(state));
  } catch (e) {
    console.error('Storage write error:', e);
  }
}

// Ottieni lo storico missioni completate
export function getHistory() {
  try {
    const raw = localStorage.getItem(KEYS.HISTORY);
    return raw ? JSON.parse(raw) : [];
  } catch {
    return [];
  }
}

// Aggiungi una voce allo storico
export function addToHistory(entry) {
  const history = getHistory();
  history.unshift({ ...entry, completedAt: new Date().toISOString() });
  // Mantieni solo gli ultimi 100 record
  const trimmed = history.slice(0, 100);
  try {
    localStorage.setItem(KEYS.HISTORY, JSON.stringify(trimmed));
  } catch (e) {
    console.error('Storage write error:', e);
  }
}

// Streak management
export function getStreak() {
  try {
    const raw = localStorage.getItem(KEYS.STREAK);
    return raw ? JSON.parse(raw) : { current: 0, best: 0, lastDate: null };
  } catch {
    return { current: 0, best: 0, lastDate: null };
  }
}

export function updateStreak(dateString) {
  const streak = getStreak();
  const today = dateString;
  const yesterday = getPreviousDateString(today);

  if (streak.lastDate === today) return streak; // già aggiornato oggi

  if (streak.lastDate === yesterday) {
    streak.current += 1;
  } else {
    streak.current = 1; // reset
  }
  streak.best = Math.max(streak.best, streak.current);
  streak.lastDate = today;

  try {
    localStorage.setItem(KEYS.STREAK, JSON.stringify(streak));
  } catch (e) {
    console.error('Storage write error:', e);
  }
  return streak;
}

// Badge management
export function getBadges() {
  try {
    const raw = localStorage.getItem(KEYS.BADGES);
    return raw ? JSON.parse(raw) : [];
  } catch {
    return [];
  }
}

export function awardBadge(badgeId) {
  const badges = getBadges();
  if (badges.includes(badgeId)) return false;
  badges.push(badgeId);
  try {
    localStorage.setItem(KEYS.BADGES, JSON.stringify(badges));
    return true;
  } catch {
    return false;
  }
}

// Totale missioni completate
export function getTotalCompleted() {
  try {
    return parseInt(localStorage.getItem(KEYS.TOTAL_COMPLETED) || '0', 10);
  } catch {
    return 0;
  }
}

export function incrementTotalCompleted() {
  const current = getTotalCompleted();
  const newVal = current + 1;
  try {
    localStorage.setItem(KEYS.TOTAL_COMPLETED, String(newVal));
  } catch {}
  return newVal;
}

// Utility: ottieni stringa data YYYY-MM-DD locale
export function getTodayString() {
  const now = new Date();
  return `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}-${String(now.getDate()).padStart(2, '0')}`;
}

function getPreviousDateString(dateStr) {
  const d = new Date(dateStr + 'T12:00:00');
  d.setDate(d.getDate() - 1);
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
}

// Reset debug
export function resetAllData() {
  Object.values(KEYS).forEach(k => localStorage.removeItem(k));
}
